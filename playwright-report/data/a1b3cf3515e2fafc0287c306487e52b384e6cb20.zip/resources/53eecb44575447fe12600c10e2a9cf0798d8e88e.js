/*
 +------------------------------------------------------------------------+
| Lock screen finnal version                                              |
| 12-12-2017                                                              |
|                                                                         |
+-------------------------------------------------------------------------+
| o Developer : Harry Tr                                                  |
| o HomePage  : http://www.hanbiro.com/                                   |
| o Email     : hung.tv@hanbiro.com                                       |
+-------------------------------------------------------------------------+
*/
;(function(window, angular, $, undefined){
	'use strict';
	var moduleName 	= 'HanLockscreen',
		module 		= angular.module(moduleName, []);
	var stateIdle	= 'ngw.HanLockscreenState';
	var factoryIdle = [moduleName, 'factory'].join('');

	module.factory(factoryIdle, ['$state', '$cookies', '$http', '$rootScope', '$stateParams', '$location', '$timeout',
			function($state, $cookies, $http, $rootScope, $stateParams, $location, $timeout){
		function HanLockscreenFn()
		{
			// expose configuration option
			this.idleTimeout 	= 0;
			this.idle 			= false;
			this.idleTimer 		= null;
			// Element to trigger to outside
			this.$el 			= null;
			this.tab_id 		= Math.random();

			this.eventsListent  = 'focus.lockscreen resize.lockscreen mousemove.lockscreen keyup.lockscreen';

			this.__construct();

			var _self = this;
			window.onfocus = function(){
				_self._updateTabOpening(true);

				var is_locked = $cookies.get('han_lockscreen');
				if(is_locked == 1)
				{
					redirectToLock();
				}
				else
				if($state.current.name.indexOf('Lock') !== -1)
				{
					redirectBack();
				}
			}

			return this.$el;
		}
		HanLockscreenFn.prototype = {
			__construct: function(){
				this._createElement();
				_window.off('updateIdletime').on('updateIdletime', $.context(this, '_updateIdleTime'));
			},
			_run: function(){
				var _self = this;
				if(this.idleTimeout > 0)
				{
					this.startIdleTimer();
					this._updateTabOpening(true);
					_window.off(this.eventsListent).on(this.eventsListent, $.context(this, 'startIdleTimer'));
					window.onbeforeunload = function (e) {
						_self._updateTabOpening(false);
					}
					// window.onblur = function(){
					// 	_self._updateTabOpening(false);
					// }
				}
			},
			_createElement: function(){
				this.$el = $('<div data-lockscreen="true" />').data('HanLockscreen', this);
			},
			_updateIdleTime: function(e, data){
				if(typeof data == 'undefined') data = 0;
				console.log('Oh Change idle time:', data);
				// $cookies.remove('tab_opening');
				if(data > 0)
				{
					this.idleTimeout = data;
					this._run();
				}
				else{
					this.idleTimeout = 0;
					_window.off(this.eventsListent);
					clearTimeout(this.idleTimer);
				}
			},
			_getTabOpening: function(){
				var $num 	= $cookies.get('tab_opening'),
					$tabs 	= $num ? angular.fromJson($num) : [];

				return $tabs;
			},
			_updateTabOpening: function(type){
				var $tabs = this._getTabOpening();

				if(type)
				{
					if($tabs.indexOf(this.tab_id) === -1)
					{
						$tabs.push(this.tab_id);
					}
				}
				else
				{
					$tabs.splice($tabs.indexOf(this.tab_id), 1);
				}

				$cookies.put('tab_opening', JSON.stringify($tabs), {path: '/'});
			},
			_isCanLock: function(){
				var $tabs = this._getTabOpening();
				/**
	             * [gw.bmwdongsung.co.kr][Lock time] error
	             * @author Huu Phuoc
	             * @Date   2024-07-05
	             * @Ticket GQ-227254
	             * @Email  phuocnh@hanbiro.com
	             */
				// $tabs.splice($tabs.indexOf(this.tab_id), 1);
				// return $tabs.length ? false : true;
				var last_item = $tabs.pop();
				return this.tab_id == last_item ? true : false;
			},
			_restartIdle: function(){
				clearTimeout(this.idleTimer);
			},
			startIdleTimer: function(e){
				if(e && e.type == 'focus')
				{
					

				}

				this._restartIdle();

				if(this.idle) this.$el.trigger('idle:stop'); // If idle, send stop event
				this.idle = false; // not idle

				var timeout = ~~this.idleTimeout; // to integer
				this.idleTimer = setTimeout($.context(this, 'idleStart'), timeout); // new Timer
			},
			idleStart: function(){
				if (!this.idle && !$rootScope.appLocked && $rootScope.isLogged) this.$el.trigger('idle:start');
	    		this.idle = true;
			}
		}

		var redirectToLock = function(){
			if(!$rootScope.appLocked && (window.location.hash).indexOf('lock') === -1){
				$state.go(stateIdle, { params: base64_encode(window.location.hash) });
			}
		}

		var redirectBack = function(){
			$timeout(function(){
				$rootScope.appLocked = false;
	    		$location.path( base64_decode($stateParams.params).replace('#', '') );
				$location.replace();
				
				// refresh all elements
				setTimeout(function(){
					_window.trigger('resize');
				}, 500)
			})
		}

		var 
			idleStart = function(){
				console.log('Idle Start');
				if(!$cookies.get('tab_opening')) return;

				// Check force-logout
				if ($rootScope.configData.lock_type == 'force-logout') {					
					if (typeof $rootScope.logOut === "function") {
						$rootScope.logOut();
						return;
					} else {
						console.log('Error: $rootScope.logOut is not defined');
					}
				}

				var _lockObj = window.lockscreen.data('HanLockscreen');
				if(_lockObj._isCanLock && !_lockObj._isCanLock())
				{
					_lockObj._updateTabOpening(false);
					_lockObj._restartIdle();
					return;
				}
				$cookies.put('han_lockscreen', 1, {path: '/'});
				redirectToLock();
			},
			idleStop  = function(){
				var _lockObj = window.lockscreen.data('HanLockscreen');
				_lockObj._updateTabOpening(true);
				console.log('Idle Stop');
			}

		return {
			run: function() {
				window.lockscreen = new HanLockscreenFn()
					.on('idle:start', idleStart)
					.on('idle:stop', idleStop)
			},
			redirectToLock: function(){
				return redirectToLock();
			},
			redirectBack: function(){
				return redirectBack();
			}
		}
	}])
	module
	.run([factoryIdle, '$rootScope', '$state', function(factoryIdle, $rootScope, $state){
		// just run when page loaded
		_window.one('loadingFinish', factoryIdle.run);

		// Create event for app can call everywhere
		$rootScope.$on('idleStart', function(){
			factoryIdle.redirectToLock();
		})

		// _window.on('focus')
	}])
	.config(['$stateProvider','$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
		$stateProvider
		.state(stateIdle, {
			url: '/lock/*params',
			onEnter: ['$rootScope', '$cookies', factoryIdle, function($rootScope, $cookies, factoryIdle){
				$rootScope.appLocked = true;
				$rootScope.isReadly  = true;
				$rootScope.isLockScreenMaster = true;
				if(!$cookies.get('han_lockscreen'))
				{
					factoryIdle.redirectBack();
				}
			}],
			views:{
				'lockscreen':{
					templateUrl: [baseConfig.tplPath, 'lock.html'].join('/'),
					controller: ['$scope', '$rootScope', 'loginService', factoryIdle, '$timeout', '$cookies', 
					function($scope, $rootScope, loginService, factoryIdle, $timeout, $cookies){
                        $scope.error = {};
                        
                        

						$scope.onKeyUp = function(e){
                            console.log(e.keyCode);
                            if(checklang(e.target))
                            {
                                e.preventDefault();
                                return false;
                            }
							// $scope.password = $(e.target).text();
                        }
                        
                        setInterval(function(){
                            $timeout(function(){
                                $scope.unique_name = generateUUID();
                            })
                        }, 5000)

						$scope.unique_name = generateUUID();
						$scope.loginForm = function(){
							var params = {
	                            gw_id: $rootScope.userData.user_data.id,
	                            gw_pass: window.$loginInput2 ? window.$loginInput2.val() : $('#iframePassword').contents().find('input').val(),
	                            auto_save_id: 1,
	                            is_lockscreen: 1
	                        };

	                        loginService.Login(params, function(data) {
								$scope.password = '';
	                        	if(data.accessGranted)
	                        	{
	                        		$scope.error = {
	                        			message: '',
	                        			show: false
	                        		}
											/**
											 * On Safari, the cookie can't be deleted immediately. Cause when user focuses to the page, it will redirect to lockscreen.
											 * So I will set the cookie to 0, representing falsy value.
											 * @ticket GQ-252794
											 */
											// Check if Safari
											var ua = window.navigator.userAgent;
											var isSafari = /Safari/.test(ua) && /Apple Computer/.test(ua);
											if(isSafari) {
												$cookies.put('han_lockscreen', 0, {path: '/'});
											}
	                        		factoryIdle.redirectBack();
	                        	}
	                        	else
	                        	{
	                        		$scope.error = {
	                        			message: data.msg,
	                        			show: true
	                        		}
	                        	}
	                        });
						}
					}]
				}
			}
		})
	}])

})(window, angular, jQuery)